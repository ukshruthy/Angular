import { Component, OnInit } from '@angular/core';
//import { count } from 'console';
import {NgModule}           from '@angular/core';

@Component({
  selector: 'app-song-list',
  templateUrl: './song-list.component.html',
  styleUrls: ['./song-list.component.css']
})
export class SongListComponent implements OnInit{
  

Playlist = [{name:'Hip-Hop song'},{name:'Pop-Up song'},{name:'Melody song'},];

//isDisabled= false ;//enabled
//sapplySpecialClass = false ;
hiddenProperty :boolean= true;
sname:string='';
  list: string;

//sssenteredValue="";
//items = [{name:'song1',val: 1},{name:'song2',val: 1},{name:'song3',val: 1}]
//selectedValue: String = '';
ngOnInit(){

}
  buttonClicked(event : Event)
  {
    this.hiddenProperty = !this.hiddenProperty;
    
  }
  
  setValue()
  {
   
    
    this.Playlist.push({name:this.sname})

  }
  
  
}

