import { CompileStylesheetMetadata } from '@angular/compiler';
import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';


import { SongListComponent } from './song-list.component';

describe('SongListComponent', () => {


  //component class testing
describe('Component Class',() =>{
  let comp:SongListComponent;
  let Playlist:string[]=[];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ FormsModule ],
      declarations: [ SongListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    const fixture = TestBed.createComponent(SongListComponent);
    comp = fixture.componentInstance;
    fixture.detectChanges();
  });
  
  beforeEach(()=>{
    console.log('*****Before each test length of songs increase on an event');
    console.log(comp.Playlist.length);
  })

  it(`should have total songs after angular calls ngOnIntit`,()=>{
    comp.ngOnInit();
    expect(comp.Playlist.length).toEqual(comp.Playlist.length);
  });

  it(`should toggle total number of songs display on button event`,()=>{
    expect(comp.hiddenProperty).toBe(true, 'display total songs at first');
    comp.buttonClicked(event);
    expect(comp.hiddenProperty).toBe(false, 'do not display total songs');
    comp.buttonClicked(event);
    expect(comp.hiddenProperty).toBe(true, 'display total songs again');
    
  });

   it(`should have songs list after construction`,()=>{
     expect(comp.Playlist).toBeTruthy();
   });

   it('#setValue should return real value on button event AddSong', () => {
    return expect(comp.setValue()).toBe();
  });
  
});

  // component Dom testing
  describe('Component DOM',()=>{
  let component: SongListComponent;
  let fixture: ComponentFixture<SongListComponent>;
 
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ FormsModule ],
      declarations: [ SongListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SongListComponent);
    component = fixture.componentInstance;
    let Playlist:string[]=[];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('set list some default value', () => {
    component.list = 'some text';
    expect(component.list).toContain('some text');
  });

  

  it(`should render title in a h2 tag`,()=>{
    const fixture = TestBed.createComponent(SongListComponent);
    fixture.detectChanges();
    const appElement: HTMLElement = fixture.nativeElement;
    const h2: HTMLElement=appElement.querySelector('h2');
    expect(h2.textContent).toEqual('Number of songs in my playlist : 3')
  });

  it(`should render a Toggle number of songs button`,()=>{
    const compiled = fixture.nativeElement;
    expect(compiled.querySelectorAll('button')[0].textContent).toEqual('Toggle Number of Songs');
  });

  it(`should render title in a h4 tag`,()=>{
    const fixture = TestBed.createComponent(SongListComponent);
    fixture.detectChanges();
    const appElement: HTMLElement = fixture.nativeElement;
    const h4: HTMLElement=appElement.querySelector('h4');
    expect(h4.textContent).toEqual('My Playlist');
  });

  it(`should render Enter new song as label`,()=>{
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('label').textContent).toEqual('Enter new song :');
  });
  
  it(`should render a text box to accept Enter new song `,()=>{
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('input[type="text"][placeholder ="newsong"]')).toBeTruthy();
  });

  it(`should render a Add song button`,()=>{
    const com = fixture.nativeElement;
    expect(com.querySelectorAll('button')[1].textContent).toEqual('Add Song');
  });
});



});
