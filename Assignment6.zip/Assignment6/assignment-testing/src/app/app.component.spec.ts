import { DebugElement } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'AssignmentTesting'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('AssignmentTesting');
  });

  it('should render title', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('FED Assignment1 : Built in Directives and Data Binding');
  });
 

//Component DOM testing (using fixture.debugElement for non-browser environment)
it(`should render title in a h1 tag`,()=>{
  const fixture = TestBed.createComponent(AppComponent);
  fixture.detectChanges();
  const appDee: DebugElement = fixture.debugElement;
  const h1Dee=appDee.query(By.css('h1'));
  const h1: HTMLElement = h1Dee.nativeElement;
  expect(h1.textContent).toEqual('FED Assignment1 : Built in Directives and Data Binding');
});

});
