import { Injectable } from '@angular/core';
import { Router ,CanActivate,CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthgaurdService{

 loggedIn: boolean = true;
 // loggenInUser : String = ""
  canActivate():boolean{
    if(confirm("Are you sure want to view the details..?"))
    {
      
    return true;
    }
     else{
       this.router.navigate(['Songs'])
     }
  }
  canDeactivate():boolean{
    if(confirm("Are you sure want to exit without saving..?"))
    {
       
    return true;
    }
     else{
      this.router.navigate(['AddSongs']) 
     }
  }
  
  constructor(private router: Router) { }
  
  }

