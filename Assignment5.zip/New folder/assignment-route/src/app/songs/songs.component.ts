import { Component, OnInit } from '@angular/core';
import {  SongsdataService } from '../songsdata.service';
  import { ProviderAst } from '@angular/compiler';
  import { HttpClient} from '@angular/common/http';
  import {NgModule} from '@angular/core';
  import { HttpErrorResponse, HttpHeaders } from '@angular/common/http';
  import { throwError } from 'rxjs'
  import { tap } from 'rxjs/Operators'
  import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { MysongsdataService } from 'projects/assignment3/src/app/mysongsdata.service';

  
  
  const httpOptions = {
    headers: new HttpHeaders({ 'content-type': 'application/json'})
  };


@Component({
  selector: 'app-songs',
  templateUrl: './songs.component.html',
  styleUrls: ['./songs.component.css']
})
export class SongsComponent implements OnInit {

  
  constructor(private songsdataService: SongsdataService) { console.log("In service constructor")}
  
  public sSong: String;
  public sAlbum: String;
  public sSingers: String;
  public sYear: Number;
  public sGenre: String;
  mysong: string[] = [];


  ngOndestroy(){
    console.log("Destroy called...")
  }
  ngOnInit(){
    console.log('onInit');
    this.songsdataService.getdata().subscribe(
      data=>{
        this.mysong = data as string[];
      },
      (err: HttpErrorResponse)=>{console.log(err.message)}
    );
  }
  
     
      private handleError(error:HttpErrorResponse){
        if(error.error instanceof ErrorEvent){
          console.error('An error occurred:',error.error.message);
        }else{
          console.error(
            `Backend returned code ${error.status},` +
            `body was: ${error.error}`);
          
        }
  
        return throwError(
          'Something bad happened: please try again later.'
        );
        }; 
        addSong(){
         
           this.songsdataService.addSong(this.sSong,this.sAlbum,this.sSingers,this.sYear,this.sGenre).subscribe(
            result => {alert("successfully added the song")},
        
            error =>{this.handleError(error)}
          );
          
        }
        editentry(Song)
        {
          Song.Song = Song.Song + "a";
          var obj = { Song: Song.Song, Album:Song.Album};
          const body = JSON.stringify(obj);
  
           this.songsdataService.editentry(obj).subscribe(
            result => {alert("successfully edited")},
            error => {this.handleError(error)}
          );
          
        }
        deleteentry(id)
        {
         // const url =`http://localhost:3000/Songs/${id}`;
         this.songsdataService.deleteentry(id).subscribe();
        }
      
       
        }     
  
  
  




