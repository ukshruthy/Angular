import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup , FormControl,Validators,AbstractControl,NG_VALIDATORS} from '@angular/forms';
import { Directive } from '@angular/core';
import { NgModel } from '@angular/forms';
import { SongsdataService } from '../songsdata.service';
import { Router } from '@angular/router';



@Component({
  selector: 'app-add-songs',
  templateUrl: './add-songs.component.html',
  styleUrls: ['./add-songs.component.css']
})
export class AddSongsComponent implements OnInit {

  SongsForm: FormGroup;
  //songname:any;
  public sSong: String;
  public sAlbum: String;
  public sSingers: String;
  public sYear: Number;
  public sGenre: String;
 
  Genre: string[]=["","Soul Music","Romantic","PoPUp ","Melody","SoundTrack","HipHop","Others"];
  constructor(private _fb: FormBuilder, private songsdataService: SongsdataService,private router:Router)  { }
  
  ngOnInit(): void {
    
    this.SongsForm = new FormGroup({
      songname: new FormControl('',[Validators.required,Validators.minLength(6)]),
      singername: new FormControl('',[Validators.required]),
      Albumname: new FormControl('',[Validators.required]),
      genre: new FormControl([Validators.required]),
      year: new FormControl('',[Validators.required])
      
   });

  }
  
  addDetails(){
         
    this.songsdataService.addSong(this.sSong,this.sAlbum,this.sSingers,this.sYear,this.sGenre).subscribe(
     result => {alert("successfully added the song")},
 );
   
 }
  
  
  
  

}
