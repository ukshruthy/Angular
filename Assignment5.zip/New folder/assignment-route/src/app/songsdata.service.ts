import { Injectable } from '@angular/core';
import { Component, OnInit } from '@angular/core';
  import { HttpClient} from '@angular/common/http';
  import {NgModule} from '@angular/core';
  import { FormsModule } from '@angular/forms';
  import { HttpErrorResponse, HttpHeaders } from '@angular/common/http';
  import { throwError } from 'rxjs'
  import { tap } from 'rxjs/Operators'
  
  const httpOptions = {
    headers: new HttpHeaders({ 'content-type': 'application/json'})
  };


@Injectable({
  providedIn: 'root'
})
export class SongsdataService {

  
    public sSong: String;
    public sAlbum: String;
    public sSingers: String;
  public sYear: Number;
  public sGenre: String;
    // mytextfiltereadingerror;
    //mytextfiledata;
    mysong: string[] = [];
    
    constructor(private myhttpService: HttpClient) { console.log("In service constructor")}
  
    getdata(){
      console.log('onInit');
    return this.myhttpService.get('http://localhost:3000/Songs');
    }
  
    addSong(sSong:String,sAlbum:String,sSingers:String,sYear:Number,sGenre:String){
      //var obj = {Song: this.sSong, Album:this.sAlbum};
      const body = JSON.stringify({Song:sSong,Album:sAlbum,Singers:sSingers,Year:sYear,Genre:sGenre});
  
      return this.myhttpService.post('http://localhost:3000/Songs',body, httpOptions);
    }
  
       editentry(Song)
       {
         Song.Song = Song.Song + "a";
         var obj = { Song: Song.Song, Album:Song.Album};
         const body = JSON.stringify(obj);
  
        return this.myhttpService.post('http://localhost:3000/Songs',body, httpOptions);
  
       }
          deleteentry(id)
          {
            const url =`http://localhost:3000/Songs/${id}`;
          return this.myhttpService.delete(url,httpOptions);
          }

          getData(id){
            return this.myhttpService.get('http://localhost:3000/Songs');
          }
        
   
}
  



