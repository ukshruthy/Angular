import { TestBed } from '@angular/core/testing';

import { SongsdataService } from './songsdata.service';

describe('SongsdataService', () => {
  let service: SongsdataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SongsdataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
