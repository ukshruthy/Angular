import { HttpErrorResponse } from '@angular/common/http';
import { Route } from '@angular/compiler/src/core';
import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import {  SongsdataService } from '../songsdata.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
 
  
 
 constructor(private _Activatedroute:ActivatedRoute,private router:Router,private SongsdataService:SongsdataService){}
 
sub;
ID;
Song;
mus:any[]=[];
//music:string[]=[];
ngOnInit(){
  this.sub=this._Activatedroute.paramMap.forEach(

  params=>{
         
    console.log(params);
    this.Song = params.get('id');
    console.log(this.Song);
  
  });

      this.SongsdataService.getdata().subscribe( data => {
      this.mus = data as string[]
      this.ID = this.mus.find(card => card.id == this.Song);
    });
  
  }
        
        
}


