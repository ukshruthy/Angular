import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AuthgaurdService } from './authgaurd.service';
import { DetailsComponent } from './details/details.component';
import { SongsComponent } from './songs/songs.component';

const routes: Routes = [
  {
    path:'About',
    component:AboutComponent
  },
  {
    path:'Songs',
    component:SongsComponent
  },
  {
    path:'Songs/:id/:Song',
    component:DetailsComponent,
    canActivate:[AuthgaurdService]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
