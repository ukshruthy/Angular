import { Component, Input ,Output,OnInit, EventEmitter } from '@angular/core';
import {NgModule}           from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Assignment1';
 
  countChanged:number=3;
 ngOnInit():void{
  
 }
 setValue($event){ 
  this.countChanged++;

} 

 
 
}


 




