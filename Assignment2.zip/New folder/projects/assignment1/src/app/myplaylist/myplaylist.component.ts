import { Component, Input, OnInit, OnChanges } from '@angular/core';

@Component({
  selector: 'app-myplaylist',
  templateUrl: './myplaylist.component.html',
  styleUrls: ['./myplaylist.component.css']
})
export class MyplaylistComponent implements OnInit {

  constructor() { }
@Input() SelectedSongs :any;
@Input() PlaylistAddButtons:boolean;
PlaylistAdded:boolean=false;
Playlist:any=[];
  ngOnInit(): void {
    
  }
  ngOnChanges (){
    this.Playlist=this.SelectedSongs;
    this.PlaylistAdded=this.PlaylistAddButtons;
  }


}
