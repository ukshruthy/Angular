//import { analyzeAndValidateNgModules, mergeNsAndName } from '@angular/compiler';
import { Component, Input, Output,OnInit,EventEmitter } from '@angular/core';
import { MyplaylistComponent } from '../myplaylist/myplaylist.component';
//import { pipe } from 'rxjs';
//import { MyplaylistComponent } from '../myplaylist/myplaylist.component';


@Component({
  selector: 'app-song-list',
  templateUrl: './song-list.component.html',
  styleUrls: ['./song-list.component.css']
})
export class SongListComponent implements OnInit{

  @Output() countChanged: EventEmitter<number> = new EventEmitter();
  disabledAgreement: boolean;

  
ngOnInit(){
  
}
Playlist:any = [{id:1,name:'Hip-Hop song',isselected:false},{id:2,name:'Pop-Up song',isselected:false},{id:3,name:'Melody song',isselected:false},];
PlaylistAddButtons:boolean=false;
song:any =[];
Mysongs:any=[];
isselected : boolean;
issname = false;
disabled:boolean=true;
//hiddenProperty = true;
sname:string;
 
 /*buttonClicked(event : Event)
  {
    
    this.hiddenProperty = !this.hiddenProperty;
    
  }*/
 
  
  setValue(){
    
   
    this.Playlist.push({id:this.Playlist.length+1,name:this.sname,isselected:false});
      this.countChanged.emit(this.Playlist);
    
      }

  OnChange(s){
    
      //this.song=this.Playlist.filter(x=>x.isselected==true).map(x=>x.name);
    //return false;
    //console.log(this.song);
    
   this.disabled=false;
    
//console.log(s);



     }
 onSubmit(){
  this.PlaylistAddButtons=true;
 
      }

    }