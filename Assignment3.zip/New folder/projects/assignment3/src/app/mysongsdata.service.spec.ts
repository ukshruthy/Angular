import { TestBed } from '@angular/core/testing';

import { MysongsdataService } from './mysongsdata.service';

describe('MysongsdataService', () => {
  let service: MysongsdataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MysongsdataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
