import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule , HTTP_INTERCEPTORS} from '@angular/common/http';
import { AppComponent } from './app.component';
//import { MyInterceptor } from './myinterceptor';
import { SongsListComponent } from './songs-list/songs-list.component';
import { MysongsdataService } from './mysongsdata.service';

@NgModule({
  declarations: [
    AppComponent,
    SongsListComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    AppRoutingModule
  ],
  providers: [MysongsdataService],
  bootstrap: [AppComponent]
})
export class AppModule { }
