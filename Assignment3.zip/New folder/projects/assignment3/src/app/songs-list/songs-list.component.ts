
import { Component, OnInit } from '@angular/core';
import {  MysongsdataService } from '../mysongsdata.service';
import { ProviderAst } from '@angular/compiler';
import { HttpClient} from '@angular/common/http';
import {NgModule} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { throwError } from 'rxjs'
import { tap } from 'rxjs/Operators'


const httpOptions = {
  headers: new HttpHeaders({ 'content-type': 'application/json'})
};


@Component({
  selector: 'app-songs-list',
  templateUrl: './songs-list.component.html',
  styleUrls: ['./songs-list.component.css']
})



export class SongsListComponent implements OnInit {

 constructor(private mysongsdataService: MysongsdataService) { console.log("In service constructor")}

public sSong: String;
public sAlbum: String;
mysong: string[] = [];

ngOndestroy(){
  console.log("Destroy called...")
}
ngOnInit(){
  console.log('onInit');
  this.mysongsdataService.getdata().subscribe(
    data=>{
      this.mysong = data as string[];
    },
    (err: HttpErrorResponse)=>{console.log(err.message)}
  );
}

   
    private handleError(error:HttpErrorResponse){
      if(error.error instanceof ErrorEvent){
        console.error('An error occurred:',error.error.message);
      }else{
        console.error(
          `Backend returned code ${error.status},` +
          `body was: ${error.error}`);
        
      }

      return throwError(
        'Something bad happened: please try again later.'
      );
      }; 
      addSong(){
       
         this.mysongsdataService.addSong(this.sSong,this.sAlbum).subscribe(
          result => {alert("successfully added the song")},
      
          error =>{this.handleError(error)}
        );
        
      }
      editentry(Song)
      {
        Song.Song = Song.Song + "a";
        var obj = { Song: Song.Song, Album:Song.Album};
        const body = JSON.stringify(obj);

         this.mysongsdataService.editentry(obj).subscribe(
          result => {alert("successfully edited")},
          error => {this.handleError(error)}
        );
        
      }
      deleteentry(id)
      {
        const url =`http://localhost:3000/Songs/${id}`;
       this.mysongsdataService.deleteentry(id).subscribe();
      }



      }     


